template<class T>
//Pham Thanh Hai-20211015
map<T, double> fuzzy_set_union(const map<T, double> &a, const map<T, double> &b) {
    map<T,double> c = a;
    for (auto it : b) {
        auto p = c.find(it.first);
        if (p!=c.end()) {
            double maxRes = max(it.second, (*p).second);
            if((*p).second != maxRes) {
                (*p).second = maxRes;
            }
        }
        else c.insert({it.first, it.second});
    }
    return c;
}

template<class T>

map<T, double> fuzzy_set_intersection(const map<T, double> &a, const map<T, double> &b) {
   map<T,double> c;
    for (auto it : a) {
        for (auto i : b) {
            if (it.first == i.first) {
                double minRes = (it.second <= i.second)? it.second : i.second;
                c.insert({it.first,minRes});
            }
        }
    }
    return c;
    

}

