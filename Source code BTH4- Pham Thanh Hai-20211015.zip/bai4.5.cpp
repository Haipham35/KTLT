void dfs(vector< list<int> > adj) {
	//Pham Thanh Hai-20211015
    stack<int> S;
    vector<bool> visited(adj.size());
    S.push(1); // B?t d?u t? d?nh s? 1
   
    while (!S.empty()) {
        int u=S.top();
        if (!visited[u]){
            visited[u] = true;
            std::cout<< u << std::endl;
        }
        if (!adj[u].empty()){
            int v=adj[u].front(); adj[u].pop_front();
            if(!visited[v]){
                S.push(v);
            }
        }else { S.pop();}
    }
}
