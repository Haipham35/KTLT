double area(Point a, Point b, Point c) {
//PHAM THANH HAI-20211015
    double x = (b.first - a.first)*(c.second - a.second);
    double y = (c.first - a.first)*(b.second - a.second);
    return 0.5*fabs(x-y);

}
